<?php 
$setting = ["mail_to" => "x13spammer@outlook.com","debug_mode" => false];
?>